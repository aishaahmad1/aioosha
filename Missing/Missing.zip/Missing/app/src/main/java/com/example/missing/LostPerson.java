package com.example.missing;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.InputStream;
import java.util.Calendar;

public class LostPerson extends AppCompatActivity {

    Database db = new Database(this);
    EditText etSelectData, email;
    ImageButton imagebutton;
    Button btn_show;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lostperson);

        etSelectData = (EditText) findViewById(R.id.etSelectData);
        email = (EditText) findViewById(R.id.desc);
        btn_show = (Button) findViewById(R.id.btnShow);
        imagebutton = (ImageButton) findViewById(R.id.imageButton);

        final Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);

        etSelectData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog dialog = new DatePickerDialog(LostPerson.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        month = month+1;
                        String date = dayOfMonth+ "/"+month+"/"+year;
                        etSelectData.setText(date);
                    }
                },year,month,day);
                dialog.show();
            }
        });

        btn_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity();
            }
        });
    }
    public void openActivity()
    {
        Intent intent = new Intent(this, Show.class);
        startActivity(intent);
    }

    public void openGallerie(View view)
    {
        Intent intentimg = new Intent(Intent.ACTION_GET_CONTENT);
        intentimg.setType("image/*");
        startActivityForResult(intentimg,100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == RESULT_OK && requestCode ==100){
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap decodeStream = BitmapFactory.decodeStream(inputStream);
                imagebutton.setImageBitmap(decodeStream);
            }catch (Exception ex){
                Log.e("ex",ex.getMessage());
            }
        }
    }

    public void btn_add_data(View view) {
        String NAME = etSelectData.getText().toString();
        String EMAIL = email.getText().toString();
        boolean resulte = db.insertData(NAME,EMAIL);

        if(resulte == true)
        {
            Toast.makeText(this,"OK",Toast.LENGTH_SHORT).show();
            etSelectData.setText("");
            email.setText("");
        }
        else {
            Toast.makeText(this, "NO", Toast.LENGTH_SHORT).show();
        }
    }

}